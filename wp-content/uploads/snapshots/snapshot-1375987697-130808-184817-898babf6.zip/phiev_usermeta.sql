CREATE TABLE IF NOT EXISTS `phiev_usermeta` (
  `umeta_id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `user_id` bigint(20) unsigned NOT NULL DEFAULT '0',
  `meta_key` varchar(255) DEFAULT NULL,
  `meta_value` longtext,
  PRIMARY KEY (`umeta_id`),
  KEY `user_id` (`user_id`),
  KEY `meta_key` (`meta_key`)
) ENGINE=InnoDB AUTO_INCREMENT=15 DEFAULT CHARSET=utf8;
TRUNCATE TABLE `phiev_usermeta`;
 
INSERT INTO `phiev_usermeta` VALUES ('1', '1', 'first_name', ''); 
INSERT INTO `phiev_usermeta` VALUES ('2', '1', 'last_name', ''); 
INSERT INTO `phiev_usermeta` VALUES ('3', '1', 'nickname', 'admin'); 
INSERT INTO `phiev_usermeta` VALUES ('4', '1', 'description', ''); 
INSERT INTO `phiev_usermeta` VALUES ('5', '1', 'rich_editing', 'true'); 
INSERT INTO `phiev_usermeta` VALUES ('6', '1', 'comment_shortcuts', 'false'); 
INSERT INTO `phiev_usermeta` VALUES ('7', '1', 'admin_color', 'fresh'); 
INSERT INTO `phiev_usermeta` VALUES ('8', '1', 'use_ssl', '0'); 
INSERT INTO `phiev_usermeta` VALUES ('9', '1', 'show_admin_bar_front', 'true'); 
INSERT INTO `phiev_usermeta` VALUES ('10', '1', 'phiev_capabilities', 'a:1:{s:13:"administrator";b:1;}'); 
INSERT INTO `phiev_usermeta` VALUES ('11', '1', 'phiev_user_level', '10'); 
INSERT INTO `phiev_usermeta` VALUES ('12', '1', 'dismissed_wp_pointers', 'wp330_toolbar,wp330_saving_widgets,wp340_choose_image_from_library,wp340_customize_current_theme_link,wp350_media,wp360_revisions,wp360_locks'); 
INSERT INTO `phiev_usermeta` VALUES ('13', '1', 'show_welcome_panel', '1'); 
INSERT INTO `phiev_usermeta` VALUES ('14', '1', 'phiev_dashboard_quick_press_last_post_id', '3');
# --------------------------------------------------------

